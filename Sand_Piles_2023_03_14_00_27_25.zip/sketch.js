// p5.disableFriendlyErrors = true;

var grid = [];
var next = [];
var colors = [
  { r: 0, g: 0, b: 64 },
  { r: 64, g: 128, b: 255 },
  { r: 255, g: 192, b: 0 },
  { r: 128, g: 0, b: 0 },
  { r: 255, g: 255, b: 255 },
];
var rate = 1;
var sandy = [];
var updated = [];

function setup() {
  createCanvas(500, 500);
  pixelDensity(1);
  background(0);

  for (let i = 0; i < width * height; i++) {
    grid.push(0);
    next.push(0);
  }

  let i = floor(width / 2) + floor(height / 2) * width;
  next[i] = 2**10;

  loadPixels();
}

function draw() {
  for (let t = 0; t < rate; t++) {
    for (let i in grid) {
      grid[i] = next[i];
    }
    
    for (let i = 0; i < grid.length; i++) {
      if (grid[i] >= 4) {
        next[i] -= 4;
        if (i > 0) {
          next[i - width]++;
          next[i - 1]++;
        }
        if (i < grid.length - 1) {
          next[i + 1]++;
          next[i + width]++;
        }
      }
    }
  }
}

function mousePressed() {
  render();
}

function render() {
  for (let i in grid) {
    const pixel = i * 4;
    pixels[pixel + 0] = colors[min(next[i], 4)].r;
    pixels[pixel + 1] = colors[min(next[i], 4)].g;
    pixels[pixel + 2] = colors[min(next[i], 4)].b;
  }

  updatePixels();
}